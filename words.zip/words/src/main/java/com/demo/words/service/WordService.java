package com.demo.words.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.words.model.Word;
import com.demo.words.repositary.WordRepository;


@Service
public class WordService {

	@Autowired
	private WordRepository wordRepository;
	
	public void createWord(Word word) {
		wordRepository.save(word);
	}

	public List<Word> getWords() {
		return (List<Word>) wordRepository.findAll();
	}

	public void deleteById(int id) {
		wordRepository.deleteById(id);
	}

}
