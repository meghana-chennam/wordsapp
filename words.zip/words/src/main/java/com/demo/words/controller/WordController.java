package com.demo.words.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.words.model.Word;
import com.demo.words.repositary.WordRepository;
import com.demo.words.service.WordService;

@Component
@RestController
@RequestMapping("api/v1")
public class WordController {
	@Autowired
	private WordService wordService;

	@PostMapping("/words")
	public ResponseEntity<Void> createWord(@RequestBody Word word) {

		wordService.createWord(word);
		return new ResponseEntity<>(HttpStatus.CREATED);

	}

	@GetMapping("/words")
	public ResponseEntity<List<Word>> getWords() {
		List<Word> word = wordService.getWords();
		return new ResponseEntity<List<Word>>(word, HttpStatus.OK);
	}

	@PutMapping("/words")
	public ResponseEntity<Void> updateWord(@RequestBody Word word) {

		wordService.createWord(word);
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@DeleteMapping("/words/{id}")
	public ResponseEntity<Void> deleteWord(@PathVariable int id) {

		wordService.deleteById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
