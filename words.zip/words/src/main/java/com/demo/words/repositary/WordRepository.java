package com.demo.words.repositary;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.words.model.Word;

@Repository
public interface WordRepository extends CrudRepository<Word,Integer> {
	
	
}
