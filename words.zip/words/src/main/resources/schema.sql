
create table words(id int primary key auto_increment, word varchar(30));

