package com.demo.words.words;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
